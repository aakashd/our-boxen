# Libreoffice Puppet Module for Boxen

## Usage

```puppet
include Libreoffice
```

## Required Puppet Modules

* boxen

