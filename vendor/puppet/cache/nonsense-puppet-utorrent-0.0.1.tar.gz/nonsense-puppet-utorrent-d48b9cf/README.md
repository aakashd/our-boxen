# uTorrent Puppet Module for Boxen

## Usage

```puppet
include utorrent
```

## Required Puppet Modules

* boxen

